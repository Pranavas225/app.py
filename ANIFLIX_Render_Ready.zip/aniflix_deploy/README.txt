ANIFLIX - Render deployment

1. Create a GitHub repository and upload app.py and requirements.txt.
2. In Render, choose New + -> Web Service and connect that repository.
3. Use these settings:
   Runtime: Python 3
   Build Command: pip install -r requirements.txt
   Start Command: python app.py
   Instance type: Free (if available)
4. Click Deploy. Render will provide a public URL.

The app listens on 0.0.0.0 and uses Render's PORT environment variable.
It is a discovery catalogue; it does not host movies or shows.
